package com.inducesmile.taxirental.entity;


public class PolylineObject {

    private String points;

    public PolylineObject(String points) {
        this.points = points;
    }

    public String getPoints() {
        return points;
    }
}
